# TV IMPROVEMENT — этапы 1–6

## Что реализовано
- Этап 3: поиск в LAN (SSDP/UPnP + mDNS/NsdManager) через Kotlin-плагин, MulticastLock, только приватные IP, без сканирования портов.
- Этап 4: экран «Подключение по IP» (проверка TCP), сохранение устройств (user://devices.json), список «Мои устройства».
- Этап 5: Kotlin-плагин `android_plugin/` (NetworkDiscovery, ADBManager, TVImprovementPlugin, NetUtil).
- Этап 6: подключение к Android TV по классическому ADB (порт 5555) с RSA-авторизацией, подтверждение на экране ТВ, чтение 5 свойств, панель устройства, отключение.

## Сборка (Android)
1. Установить JDK 17 и Android SDK. `cd android_plugin && ./build_plugin.sh` (нужен gradle или gradlew) — соберёт AAR в `addons/TVImprovement/bin/`.
2. Godot 4.3+: Project → Install Android Build Template; Project Settings → Plugins → включить TVImprovement.
3. Export → Android: включить **Use Gradle Build**; экспортировать.
4. В редакторе/на ПК плагина нет: приложение честно пишет, что поиск недоступен.

## Ограничения
- ADB: только классический режим (порт 5555). «Беспроводная отладка» Android 11+ с кодом сопряжения (TLS) не поддерживается.
- Samsung/LG/Roku/Cast/AirPlay/Android TV Remote — адаптеры на этапе 10 (сейчас честное «не реализовано»).
- Android 17 (targetSdk 37): ACCESS_LOCAL_NETWORK запрашивается перед поиском. Godot 4.3 по умолчанию targetSdk ниже — тогда разрешение выдаётся неявно.
- Ключ ADB хранится в приватной папке приложения (filesDir).
- Код не компилировался и не запускался в этой среде (нет Godot/Android SDK/сети) — первая сборка может потребовать правок.
