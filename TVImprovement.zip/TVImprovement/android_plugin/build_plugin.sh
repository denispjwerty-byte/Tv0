#!/bin/bash
# Собирает AAR и копирует в addons/TVImprovement/bin. Нужны JDK 17, Android SDK и gradle (или gradlew).
set -e
cd "$(dirname "$0")"
GR=./gradlew; [ -x ./gradlew ] || GR=gradle
$GR :plugin:assembleDebug :plugin:assembleRelease
D=../addons/TVImprovement/bin
mkdir -p $D/debug $D/release
cp plugin/build/outputs/aar/plugin-debug.aar   $D/debug/TVImprovement-debug.aar
cp plugin/build/outputs/aar/plugin-release.aar $D/release/TVImprovement-release.aar
echo "OK: AAR скопированы в addons/TVImprovement/bin"
