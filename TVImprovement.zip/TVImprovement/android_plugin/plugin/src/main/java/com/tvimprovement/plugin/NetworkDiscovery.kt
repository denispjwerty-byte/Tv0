package com.tvimprovement.plugin

import android.content.Context
import android.net.Network
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.SystemClock
import com.tvimprovement.plugin.NetUtil.evt
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.ExecutorService
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/** Обнаружение в ЛОКАЛЬНОЙ сети: SSDP/UPnP (multicast) и mDNS/DNS-SD (NsdManager). Никакого сканирования портов/подсетей. */
class NetworkDiscovery(ctx: Context, private val emit: (JSONObject) -> Unit) {
    private val app = ctx.applicationContext
    private val running = AtomicBoolean(false)
    private val stopFlag = AtomicBoolean(false)
    @Volatile private var socket: DatagramSocket? = null

    companion object {
        private val SSDP_TARGETS = listOf(
            "ssdp:all", "upnp:rootdevice",
            "urn:dial-multiscreen-org:service:dial:1",
            "urn:schemas-upnp-org:device:MediaRenderer:1", "roku:ecp"
        )
        private val MDNS_TYPES = listOf(
            "_androidtvremote2._tcp.", "_googlecast._tcp.", "_airplay._tcp.",
            "_samsungmsf._tcp.", "_companion-link._tcp."
        )
    }

    fun start(timeoutMs: Int) {
        if (!running.compareAndSet(false, true)) return
        stopFlag.set(false)
        thread(name = "tvi-discovery") {
            emit(evt("discovery_started"))
            try {
                run(timeoutMs.coerceIn(2000, 30000))
            } catch (e: Exception) {
                emit(evt("discovery_error", "message" to (e.message ?: e.javaClass.simpleName)))
            } finally {
                running.set(false)
                emit(evt("discovery_finished"))
            }
        }
    }

    fun stop() {
        stopFlag.set(true)
        try { socket?.close() } catch (_: Exception) {}
    }

    private fun run(timeoutMs: Int) {
        val net = NetUtil.localNetwork(app)
        if (net == null) {
            emit(evt("discovery_error", "message" to "no_local_network"))
            return
        }
        val wifi = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifi.createMulticastLock("tvimprovement").apply { setReferenceCounted(false); acquire() }
        val nsd = app.getSystemService(Context.NSD_SERVICE) as NsdManager
        val listeners = ArrayList<NsdManager.DiscoveryListener>()
        val resolveQ = LinkedBlockingQueue<NsdServiceInfo>()
        val pool = Executors.newFixedThreadPool(3)
        val seenLoc = ConcurrentHashMap.newKeySet<String>()
        val start = SystemClock.elapsedRealtime()
        val deadline = start + timeoutMs
        try {
            thread(isDaemon = true, name = "tvi-resolve") { resolverLoop(nsd, resolveQ, deadline) }
            for (t in MDNS_TYPES) {
                val l = object : NsdManager.DiscoveryListener {
                    override fun onDiscoveryStarted(serviceType: String) {}
                    override fun onServiceFound(s: NsdServiceInfo) { resolveQ.offer(s) }
                    override fun onServiceLost(s: NsdServiceInfo) {}
                    override fun onDiscoveryStopped(serviceType: String) {}
                    override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
                    override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
                }
                try {
                    nsd.discoverServices(t, NsdManager.PROTOCOL_DNS_SD, l)
                    listeners.add(l)
                } catch (_: Exception) {}
            }

            val sock = DatagramSocket(null).apply { reuseAddress = true; bind(InetSocketAddress(0)); soTimeout = 400 }
            net.bindSocket(sock)
            socket = sock
            val group = InetAddress.getByName("239.255.255.250")
            fun sendAll() {
                for (st in SSDP_TARGETS) {
                    val msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\nMX: 2\r\nST: $st\r\nUSER-AGENT: TVImprovement/0.2\r\n\r\n"
                    val b = msg.toByteArray()
                    try { sock.send(DatagramPacket(b, b.size, group, 1900)) } catch (_: Exception) {}
                }
            }
            sendAll()
            var resent = false
            val buf = ByteArray(4096)
            while (!stopFlag.get() && SystemClock.elapsedRealtime() < deadline) {
                if (!resent && SystemClock.elapsedRealtime() > start + 1500) { sendAll(); resent = true }
                try {
                    val p = DatagramPacket(buf, buf.size)
                    sock.receive(p)
                    val ip = p.address.hostAddress ?: continue
                    if (!NetUtil.isPrivateIPv4(ip)) continue
                    handleSsdp(ip, String(p.data, 0, p.length, Charsets.UTF_8), net, pool, seenLoc)
                } catch (_: SocketTimeoutException) {
                } catch (e: Exception) {
                    if (stopFlag.get()) break
                }
            }
        } finally {
            stopFlag.set(true)
            pool.shutdown()
            try { pool.awaitTermination(3, TimeUnit.SECONDS) } catch (_: Exception) {}
            for (l in listeners) { try { nsd.stopServiceDiscovery(l) } catch (_: Exception) {} }
            try { socket?.close() } catch (_: Exception) {}
            socket = null
            try { if (lock.isHeld) lock.release() } catch (_: Exception) {}
        }
    }

    private fun handleSsdp(ip: String, text: String, net: Network, pool: ExecutorService, seenLoc: MutableSet<String>) {
        if (!text.startsWith("HTTP/")) return  // только ответы на наш M-SEARCH
        val h = HashMap<String, String>()
        for (line in text.split("\r\n")) {
            val i = line.indexOf(':')
            if (i > 0) h[line.substring(0, i).trim().uppercase()] = line.substring(i + 1).trim()
        }
        emit(evt("device", "source" to "ssdp", "ip" to ip, "st" to h["ST"], "usn" to h["USN"],
            "server" to h["SERVER"]?.take(160), "location" to h["LOCATION"]?.take(300)))
        val loc = h["LOCATION"] ?: return
        if (seenLoc.add(loc)) pool.execute { fetchDescription(loc, ip, net) }
    }

    /** Читаем описание UPnP только с того же IP, что ответил (без редиректов). */
    private fun fetchDescription(loc: String, ip: String, net: Network) {
        try {
            val url = URL(loc)
            if (url.protocol != "http" || url.host != ip) return
            val c = net.openConnection(url) as HttpURLConnection
            c.connectTimeout = 2000; c.readTimeout = 2000; c.instanceFollowRedirects = false
            val body = c.inputStream.use {
                val buf = ByteArray(65536); var n = 0
                while (n < buf.size) { val r = it.read(buf, n, buf.size - n); if (r < 0) break; n += r }
                String(buf, 0, n, Charsets.UTF_8)
            }
            fun tag(t: String) = Regex("<$t>([^<]*)</$t>").find(body)?.groupValues?.get(1)?.trim()?.take(100)
            emit(evt("device", "source" to "ssdp", "ip" to ip, "name" to tag("friendlyName"),
                "manufacturer" to tag("manufacturer"), "model" to tag("modelName"), "device_type" to tag("deviceType")))
        } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun resolverLoop(nsd: NsdManager, q: LinkedBlockingQueue<NsdServiceInfo>, deadline: Long) {
        val seen = HashSet<String>()
        while (!stopFlag.get() && SystemClock.elapsedRealtime() < deadline + 500) {
            val info = q.poll(300, TimeUnit.MILLISECONDS) ?: continue
            if (!seen.add(info.serviceName + info.serviceType)) continue
            val latch = CountDownLatch(1)
            try {
                nsd.resolveService(info, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(i: NsdServiceInfo, errorCode: Int) { latch.countDown() }
                    override fun onServiceResolved(i: NsdServiceInfo) { emitMdns(i); latch.countDown() }
                })
                latch.await(3, TimeUnit.SECONDS)
            } catch (_: Exception) {}
        }
    }

    @Suppress("DEPRECATION")
    private fun emitMdns(i: NsdServiceInfo) {
        val a = i.host as? Inet4Address ?: return
        val ip = a.hostAddress ?: return
        if (!NetUtil.isPrivateIPv4(ip)) return
        val txt = JSONObject()
        try { for ((k, v) in i.attributes) txt.put(k, String(v ?: ByteArray(0), Charsets.UTF_8).take(120)) } catch (_: Exception) {}
        emit(evt("device", "source" to "mdns", "ip" to ip, "name" to i.serviceName,
            "service" to i.serviceType.trim('.'), "port" to i.port, "txt" to txt))
    }
}
