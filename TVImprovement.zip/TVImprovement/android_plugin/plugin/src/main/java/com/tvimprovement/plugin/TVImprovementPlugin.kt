package com.tvimprovement.plugin

import com.tvimprovement.plugin.NetUtil.evt
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.UsedByGodot
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.concurrent.thread

/** Мост Godot <-> Android. Результаты асинхронных операций кладутся в очередь; GDScript забирает их через pollEvents(). */
class TVImprovementPlugin(godot: Godot) : GodotPlugin(godot) {
    private val events = ConcurrentLinkedQueue<String>()
    private val emit: (JSONObject) -> Unit = { events.add(it.toString()) }
    private val app by lazy { activity!!.applicationContext }
    private val discovery by lazy { NetworkDiscovery(app, emit) }
    private val adb by lazy { ADBManager(app, emit) }

    override fun getPluginName() = "TVImprovement"

    @UsedByGodot fun getNetworkInfo(): String = NetUtil.networkInfo(app).toString()
    @UsedByGodot fun startDiscovery(timeoutMs: Int) = discovery.start(timeoutMs)
    @UsedByGodot fun stopDiscovery() = discovery.stop()

    @UsedByGodot
    fun testTcp(id: String, host: String, port: Int, timeoutMs: Int) {
        thread(name = "tvi-tcp") {
            var ok = false; var err = ""
            if (!NetUtil.isPrivateIPv4(host) || port !in 1..65535) err = "invalid_target"
            else try {
                Socket().use { s ->
                    NetUtil.localNetwork(app)?.bindSocket(s)
                    s.connect(InetSocketAddress(host, port), timeoutMs.coerceIn(500, 10000))
                    ok = true
                }
            } catch (e: Exception) { err = e.javaClass.simpleName }
            emit(evt("tcp_result", "id" to id, "ok" to ok, "host" to host, "port" to port, "error" to err))
        }
    }

    @UsedByGodot fun adbConnect(host: String, port: Int) = adb.connect(host, port)
    @UsedByGodot fun adbShell(id: String, command: String) = adb.shell(id, command)
    @UsedByGodot fun adbDisconnect() = adb.disconnect()

    @UsedByGodot
    fun pollEvents(): String {
        if (events.isEmpty()) return "[]"
        val arr = JSONArray()
        var n = 0
        while (n < 200) { val s = events.poll() ?: break; arr.put(JSONObject(s)); n++ }
        return arr.toString()
    }

    override fun onMainDestroy() {
        discovery.stop()
        adb.disconnect()
    }
}
