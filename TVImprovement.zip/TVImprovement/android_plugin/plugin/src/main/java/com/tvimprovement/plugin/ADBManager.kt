package com.tvimprovement.plugin

import android.content.Context
import android.util.Base64
import com.tvimprovement.plugin.NetUtil.evt
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.interfaces.RSAPrivateCrtKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.RSAPublicKeySpec
import java.util.concurrent.Executors

/**
 * Минимальный клиент ADB по TCP (классический режим, порт 5555) с RSA-авторизацией.
 * Ничего не обходит: телевизор сам показывает запрос «Разрешить отладку?», пока пользователь не подтвердит — соединения нет.
 * Команды ограничены белым списком.
 */
class ADBManager(ctx: Context, private val emit: (JSONObject) -> Unit) {
    private val app = ctx.applicationContext
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var socket: Socket? = null
    @Volatile private var connected = false
    @Volatile private var userClosed = false
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var nextId = 1
    private val key: KeyPair by lazy { loadOrCreateKey() }

    companion object {
        const val A_CNXN = 0x4e584e43
        const val A_AUTH = 0x48545541
        const val A_OPEN = 0x4e45504f
        const val A_OKAY = 0x59414b4f
        const val A_CLSE = 0x45534c43
        const val A_WRTE = 0x45545257
        const val VERSION = 0x01000001
        const val MAX_DATA = 256 * 1024
        val SHA1_PREFIX = byteArrayOf(0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14)
        val ALLOWED = Regex("^getprop( [A-Za-z0-9._]+)?$")
    }

    fun connect(host: String, port: Int) {
        userClosed = false
        exec.execute {
            try {
                doConnect(host, port)
            } catch (e: SocketTimeoutException) {
                fail("auth_timeout")
            } catch (e: Exception) {
                fail("connect_failed: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun fail(msg: String) {
        closeQuiet()
        if (!userClosed) emit(evt("adb_state", "state" to "error", "message" to msg))
    }

    private fun doConnect(host: String, port: Int) {
        if (!NetUtil.isPrivateIPv4(host) || port !in 1..65535) { fail("invalid_target"); return }
        closeQuiet()
        emit(evt("adb_state", "state" to "connecting"))
        val s = Socket()
        NetUtil.localNetwork(app)?.bindSocket(s)
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(host, port), 4000)
        s.soTimeout = 30000  // ждём, пока пользователь подтвердит запрос на ТВ
        socket = s; input = s.getInputStream(); output = s.getOutputStream()
        send(A_CNXN, VERSION, MAX_DATA, "host::\u0000".toByteArray())
        var sentSig = false; var sentKey = false
        while (true) {
            val m = recv()
            when (m.cmd) {
                A_CNXN -> {
                    connected = true
                    s.soTimeout = 15000
                    val banner = String(m.data, Charsets.UTF_8).trimEnd('\u0000').take(300)
                    emit(evt("adb_state", "state" to "connected", "banner" to banner))
                    return
                }
                A_AUTH -> if (m.a0 == 1) {
                    if (!sentSig) { send(A_AUTH, 2, 0, sign(m.data)); sentSig = true }
                    else if (!sentKey) {
                        emit(evt("adb_state", "state" to "waiting_auth"))
                        send(A_AUTH, 3, 0, publicKeyBlob()); sentKey = true
                    }
                }
                else -> {}
            }
        }
    }

    fun shell(id: String, command: String) {
        exec.execute {
            if (!connected) { emit(evt("adb_shell", "id" to id, "ok" to false, "error" to "not_connected")); return@execute }
            if (!ALLOWED.matches(command)) { emit(evt("adb_shell", "id" to id, "ok" to false, "error" to "command_not_allowed")); return@execute }
            try {
                emit(evt("adb_shell", "id" to id, "ok" to true, "output" to runShell(command)))
            } catch (e: Exception) {
                emit(evt("adb_shell", "id" to id, "ok" to false, "error" to (e.message ?: "io_error")))
                fail("connection_lost")
            }
        }
    }

    private fun runShell(cmd: String): String {
        val local = nextId++
        send(A_OPEN, local, 0, "shell:$cmd\u0000".toByteArray())
        var remote = 0
        val sb = ByteArrayOutputStream()
        while (true) {
            val m = recv()
            if (m.a1 != local) continue
            when (m.cmd) {
                A_OKAY -> remote = m.a0
                A_WRTE -> { if (sb.size() < 256 * 1024) sb.write(m.data); send(A_OKAY, local, m.a0) }
                A_CLSE -> { if (remote == 0) throw IOException("service_refused"); break }
            }
        }
        return String(sb.toByteArray(), Charsets.UTF_8)
    }

    fun disconnect() {
        userClosed = true
        closeQuiet()
        emit(evt("adb_state", "state" to "disconnected"))
    }

    private fun closeQuiet() {
        connected = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }

    // ---- протокол ----
    private class Msg(val cmd: Int, val a0: Int, val a1: Int, val data: ByteArray)

    private fun send(cmd: Int, a0: Int, a1: Int, data: ByteArray = ByteArray(0)) {
        val h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        var crc = 0
        for (b in data) crc += (b.toInt() and 0xff)
        h.putInt(cmd).putInt(a0).putInt(a1).putInt(data.size).putInt(crc).putInt(cmd.inv())
        val o = output ?: throw IOException("closed")
        o.write(h.array()); if (data.isNotEmpty()) o.write(data); o.flush()
    }

    private fun readFully(b: ByteArray) {
        val i = input ?: throw IOException("closed")
        var n = 0
        while (n < b.size) { val r = i.read(b, n, b.size - n); if (r < 0) throw IOException("closed_by_device"); n += r }
    }

    private fun recv(): Msg {
        val h = ByteArray(24); readFully(h)
        val bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = bb.int; val a0 = bb.int; val a1 = bb.int; val len = bb.int; bb.int; val magic = bb.int
        if (magic != cmd.inv() || len < 0 || len > MAX_DATA * 4) throw IOException("protocol_error")
        val d = ByteArray(len); if (len > 0) readFully(d)
        return Msg(cmd, a0, a1, d)
    }

    // ---- ключи ----
    private fun loadOrCreateKey(): KeyPair {
        val f = File(app.filesDir, "adbkey.pk8")  // приватное хранилище приложения
        val kf = KeyFactory.getInstance("RSA")
        if (f.exists()) {
            try {
                val priv = kf.generatePrivate(PKCS8EncodedKeySpec(f.readBytes())) as RSAPrivateCrtKey
                val pub = kf.generatePublic(RSAPublicKeySpec(priv.modulus, priv.publicExponent))
                return KeyPair(pub, priv)
            } catch (_: Exception) {}
        }
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        f.writeBytes(kp.private.encoded)
        f.setReadable(false, false); f.setReadable(true, true)
        return kp
    }

    private fun sign(token: ByteArray): ByteArray {
        val s = Signature.getInstance("NONEwithRSA")
        s.initSign(key.private)
        s.update(SHA1_PREFIX + token)
        return s.sign()
    }

    private fun le(v: BigInteger, size: Int): ByteArray {
        val be = v.toByteArray()
        val out = ByteArray(size)
        for (i in 0 until size) { val j = be.size - 1 - i; if (j >= 0) out[i] = be[j] }
        return out
    }

    private fun publicKeyBlob(): ByteArray {
        val pub = key.public as RSAPublicKey
        val n = pub.modulus
        val r32 = BigInteger.ONE.shiftLeft(32)
        val n0inv = r32.subtract(n.mod(r32).modInverse(r32)).toInt()
        val rr = BigInteger.ONE.shiftLeft(4096).mod(n)
        val bb = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(64).putInt(n0inv).put(le(n, 256)).put(le(rr, 256)).putInt(pub.publicExponent.toInt())
        val b64 = Base64.encodeToString(bb.array(), Base64.NO_WRAP)
        return ("$b64 tvimprovement@android\u0000").toByteArray()
    }
}
