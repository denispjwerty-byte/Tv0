package com.tvimprovement.plugin

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import org.json.JSONObject
import java.net.Inet4Address

object NetUtil {
    fun evt(type: String, vararg kv: Pair<String, Any?>): JSONObject {
        val o = JSONObject().put("type", type)
        for ((k, v) in kv) o.put(k, v ?: JSONObject.NULL)
        return o
    }

    /** Только частные адреса локальной сети: 10/8, 172.16/12, 192.168/16, 169.254/16. */
    fun isPrivateIPv4(host: String): Boolean {
        val p = host.trim().split(".")
        if (p.size != 4) return false
        val n = IntArray(4)
        for (i in 0..3) {
            val v = p[i].toIntOrNull() ?: return false
            if (v !in 0..255) return false
            n[i] = v
        }
        return n[0] == 10 || (n[0] == 172 && n[1] in 16..31) ||
            (n[0] == 192 && n[1] == 168) || (n[0] == 169 && n[1] == 254)
    }

    @Suppress("DEPRECATION")
    fun localNetwork(ctx: Context): Network? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        fun ok(n: Network): Boolean {
            val c = cm.getNetworkCapabilities(n) ?: return false
            return c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        }
        cm.activeNetwork?.let { if (ok(it)) return it }
        return cm.allNetworks.firstOrNull { ok(it) }
    }

    fun networkInfo(ctx: Context): JSONObject {
        val o = JSONObject().put("sdk", Build.VERSION.SDK_INT).put("connected", false)
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = localNetwork(ctx) ?: return o
        val caps = cm.getNetworkCapabilities(n)
        val addr = cm.getLinkProperties(n)?.linkAddresses?.firstOrNull { it.address is Inet4Address }
        o.put("connected", addr != null)
        o.put("transport", if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true) "ethernet" else "wifi")
        if (addr != null) {
            o.put("ip", addr.address.hostAddress)
            o.put("prefix", addr.prefixLength)
        }
        return o
    }
}
