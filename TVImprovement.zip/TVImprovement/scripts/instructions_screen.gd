extends BaseScreen
## Этап 2: просмотр каталогов брендов и приставок (данные из data/*.json).

func _ready() -> void:
	build(Loc.t("instructions"))
	_section(Loc.t("tv_catalog"), "res://data/tv_brands.json")
	_section(Loc.t("box_catalog"), "res://data/tv_boxes.json")

func _section(title: String, path: String) -> void:
	body.add_child(UI.label(title, 42, UI.ACCENT))
	for it in DeviceManager.catalog(path):
		var c := UI.card()
		var v: VBoxContainer = c.get_child(0)
		v.add_child(UI.label(it["name"], 38))
		var os_list: Array = it.get("os", [])
		var os_txt := Loc.t("os_unknown")
		if not os_list.is_empty():
			os_txt = ", ".join(PackedStringArray(os_list))
		v.add_child(UI.label(Loc.t("os") + ": " + os_txt, 28, UI.MUTED))
		var protos := DeviceManager.protocol_names_for(os_list, it.get("extra_protocols", []))
		var p_txt := Loc.t("protocols_none")
		if not protos.is_empty():
			p_txt = ", ".join(PackedStringArray(protos))
		v.add_child(UI.label(Loc.t("protocols") + ": " + p_txt, 28, UI.MUTED))
		if it.get("confirm_os", true):
			v.add_child(UI.label(Loc.t("confirm_os"), 26, UI.ERR))
		body.add_child(c)
