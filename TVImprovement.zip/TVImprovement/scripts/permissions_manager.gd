class_name PermissionsManager
extends RefCounted
## Разрешения запрашиваются только перед использованием функции.

## Android 17+ (targetSdk 37): ACCESS_LOCAL_NETWORK. На более ранних версиях отдельное runtime-разрешение не нужно.
static func ensure_local_network() -> bool:
	if not Native.available:
		return false
	if int(Native.network_info().get("sdk", 0)) < 37:
		return true
	var perm := "android.permission.ACCESS_LOCAL_NETWORK"
	if perm in OS.get_granted_permissions():
		return true
	OS.request_permission(perm)
	var tree := Engine.get_main_loop() as SceneTree
	while true:
		var r = await tree.on_request_permissions_result
		if str(r[0]).ends_with("ACCESS_LOCAL_NETWORK"):
			return bool(r[1])
	return false
