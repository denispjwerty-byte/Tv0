extends Node
## Autoload "App": навигация между экранами.

const SCREENS := {
	"splash": "res://scenes/SplashScreen.tscn",
	"main": "res://scenes/MainMenu.tscn",
	"tools": "res://scenes/Tools.tscn",
	"device_scanner": "res://scenes/DeviceScanner.tscn",
	"device_list": "res://scenes/DeviceList.tscn",
	"device_details": "res://scenes/DeviceDetails.tscn",
	"ip_connection": "res://scenes/IPConnection.tscn",
	"app_installer": "res://scenes/AppInstaller.tscn",
	"ad_cleaner": "res://scenes/AdCleaner.tscn",
	"launcher_store": "res://scenes/LauncherStore.tscn",
	"tv_remote": "res://scenes/TVRemote.tscn",
	"instructions": "res://scenes/Instructions.tscn",
	"settings": "res://scenes/Settings.tscn",
}

var current := ""
var stack: Array[String] = []

func go(id: String, push: bool = true) -> void:
	if not SCREENS.has(id):
		push_error("Unknown screen: " + id)
		return
	if push and current != "":
		stack.append(current)
	current = id
	get_tree().change_scene_to_file(SCREENS[id])

func go_root(id: String) -> void:
	stack.clear()
	current = ""
	go(id, false)

func back() -> void:
	if stack.is_empty():
		if current == "main":
			get_tree().quit()
		else:
			go_root("main")
		return
	current = stack.pop_back()
	get_tree().change_scene_to_file(SCREENS[current])

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		back()
