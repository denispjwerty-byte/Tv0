extends BaseScreen

## id экрана, ключ строки, значок
const GRID := [
	["device_list", "my_devices", "📺"],
	["ip_connection", "ip_connect", "🌐"],
	["app_installer", "install_apps", "📦"],
	["ad_cleaner", "ad_cleaner", "🧹"],
	["launcher_store", "launcher", "🚀"],
	["tv_remote", "remote", "🎮"],
	["device_details", "device_info", "ℹ"],
	["instructions", "instructions", "📖"],
]

func _ready() -> void:
	build("", false, true, "main")
	body.add_child(UI.logo(52))
	var tag := UI.label(Loc.t("tagline"), 30, UI.MUTED)
	tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.add_child(tag)

	var hero := UI.button("🔍   " + Loc.t("find_device"), true, 210)
	hero.add_theme_font_size_override("font_size", 52)
	hero.pressed.connect(App.go.bind("device_scanner"))
	body.add_child(hero)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 24)
	grid.add_theme_constant_override("v_separation", 24)
	body.add_child(grid)
	for it in GRID:
		var b := UI.card_button(it[2], Loc.t(it[1]))
		b.pressed.connect(App.go.bind(it[0]))
		grid.add_child(b)
