class_name BaseScreen
extends Control
## Общий каркас экрана: фон, шапка, прокручиваемое тело, нижняя навигация.

var body: VBoxContainer

func build(title: String = "", show_back: bool = true, show_nav: bool = true, nav_active: String = "") -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = UI.BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var outer := VBoxContainer.new()
	outer.set_anchors_preset(Control.PRESET_FULL_RECT)
	outer.add_theme_constant_override("separation", 0)
	add_child(outer)

	var top := Control.new()
	top.custom_minimum_size = Vector2(0, 64)  # отступ под статус-бар
	outer.add_child(top)

	if title != "":
		var head := HBoxContainer.new()
		head.add_theme_constant_override("separation", 20)
		var hm := MarginContainer.new()
		hm.add_theme_constant_override("margin_left", 40)
		hm.add_theme_constant_override("margin_right", 40)
		hm.add_child(head)
		outer.add_child(hm)
		if show_back:
			var back := UI.button("‹", false, 100)
			back.custom_minimum_size = Vector2(110, 100)
			back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
			back.pressed.connect(App.back)
			head.add_child(back)
		head.add_child(UI.label(title, 48))

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(scroll)
	var m := MarginContainer.new()
	m.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for side in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + side, 40)
	scroll.add_child(m)
	body = VBoxContainer.new()
	body.add_theme_constant_override("separation", 28)
	m.add_child(body)

	if show_nav:
		outer.add_child(_nav(nav_active))

	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.25)

func _nav(active: String) -> Control:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UI.box(UI.SURFACE, 0, UI.BORDER, 0, 12))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	panel.add_child(row)
	var items := [
		["main", "🏠", "nav_home"],
		["device_list", "📺", "nav_devices"],
		["tools", "🧰", "nav_tools"],
		["settings", "⚙", "nav_settings"],
	]
	for it in items:
		var b := Button.new()
		b.text = it[1] + "\n" + Loc.t(it[2])
		b.flat = true
		b.custom_minimum_size = Vector2(0, 150)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 28)
		var col := UI.ACCENT if it[0] == active else UI.MUTED
		for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
			b.add_theme_color_override(k, col)
		b.pressed.connect(App.go_root.bind(it[0]))
		row.add_child(b)
	return panel
