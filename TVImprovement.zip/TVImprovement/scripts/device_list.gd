extends BaseScreen

func _ready() -> void:
	build(Loc.t("my_devices"), false, true, "device_list")
	DeviceManager.load_saved()
	if DeviceManager.saved.is_empty():
		var c := UI.card()
		c.get_child(0).add_child(UI.label(Loc.t("saved_empty"), 32, UI.MUTED))
		body.add_child(c)
		var b := UI.button("🔍  " + Loc.t("find_device"), true, 140)
		b.pressed.connect(App.go.bind("device_scanner"))
		body.add_child(b)
		return
	for d in DeviceManager.saved:
		var c := UI.card()
		var v: VBoxContainer = c.get_child(0)
		v.add_child(UI.label(str(d.get("name", d.get("ip", ""))), 38))
		v.add_child(UI.label("IP: %s:%d" % [d.get("ip", ""), int(d.get("port", 0))], 28, UI.MUTED))
		v.add_child(UI.label(DeviceManager.protocol_name(str(d.get("protocol", ""))), 26, UI.MUTED))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 16)
		var del := UI.button(Loc.t("delete"), false, 100)
		del.pressed.connect(_delete.bind(d))
		var con := UI.button(Loc.t("connect"), true, 100)
		con.pressed.connect(_connect.bind(d))
		row.add_child(del)
		row.add_child(con)
		v.add_child(row)
		body.add_child(c)

func _connect(d: Dictionary) -> void:
	DeviceManager.pending = d.duplicate(true)
	App.go("ip_connection")

func _delete(d: Dictionary) -> void:
	UI.dialog(self, Loc.t("confirm_title"), Loc.t("delete_confirm") % str(d.get("name", d.get("ip", ""))),
		func():
			DeviceManager.remove_device(str(d.get("id", "")))
			get_tree().reload_current_scene(), true)
