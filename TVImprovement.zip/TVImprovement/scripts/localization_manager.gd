extends Node
## Autoload "Loc": строки интерфейса. Нет перевода -> английский -> ключ.

const CFG_PATH := "user://settings.cfg"
var lang := "ru"
var strings: Dictionary = {}

func _ready() -> void:
	var d = DeviceManager.load_json("res://data/strings.json")
	if d is Dictionary:
		strings = d
	var cfg := ConfigFile.new()
	if cfg.load(CFG_PATH) == OK:
		lang = str(cfg.get_value("app", "lang", "ru"))

func t(key: String) -> String:
	var cur: Dictionary = strings.get(lang, {})
	if cur.has(key):
		return cur[key]
	var en: Dictionary = strings.get("en", {})
	return en.get(key, key)

func set_lang(code: String) -> void:
	lang = code
	var cfg := ConfigFile.new()
	cfg.load(CFG_PATH)
	cfg.set_value("app", "lang", code)
	cfg.save(CFG_PATH)
