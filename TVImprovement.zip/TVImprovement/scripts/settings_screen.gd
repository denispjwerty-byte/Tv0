extends BaseScreen

const VERSION := "0.2.0 (stages 1-6)"

func _ready() -> void:
	build(Loc.t("settings"), false, true, "settings")
	body.add_child(UI.label(Loc.t("language"), 42, UI.ACCENT))
	var langs = DeviceManager.load_json("res://data/languages.json")
	for l in langs["languages"]:
		var b := UI.button(l["native"], l["code"] == Loc.lang, 110)
		if l["ready"]:
			b.pressed.connect(_pick.bind(l["code"]))
		else:
			b.disabled = true
			b.text = l["native"] + "  —  " + Loc.t("soon")
		body.add_child(b)
	body.add_child(UI.label(Loc.t("about"), 42, UI.ACCENT))
	var c := UI.card()
	var v: VBoxContainer = c.get_child(0)
	v.add_child(UI.label("TV IMPROVEMENT", 36))
	v.add_child(UI.label(Loc.t("version") + ": " + VERSION, 28, UI.MUTED))
	v.add_child(UI.label(Loc.t("free_note"), 28, UI.MUTED))
	body.add_child(c)

func _pick(code: String) -> void:
	Loc.set_lang(code)
	get_tree().reload_current_scene()
