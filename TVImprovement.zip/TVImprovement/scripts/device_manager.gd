class_name DeviceManager
extends RefCounted
## Каталоги, сохранённые устройства (user:// — приватное хранилище приложения), текущая сессия.

const SAVE_PATH := "user://devices.json"
static var saved: Array = []
static var pending: Dictionary = {}   # устройство, переданное на экран подключения
static var session: Dictionary = {}   # подключённое устройство
static var adapter: DeviceAdapter = null
static var _loaded := false

static func load_json(path: String) -> Variant:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		push_error("Cannot open " + path)
		return null
	return JSON.parse_string(f.get_as_text())

static func catalog(path: String) -> Array:
	var d = load_json(path)
	if d is Dictionary and d.has("items"):
		return d["items"]
	return []

static func protocol_ids_for(os_list: Array, extra: Array = []) -> Array:
	var p = load_json("res://data/protocols.json")
	var ids: Array = []
	if not (p is Dictionary):
		return ids
	for os_name in os_list:
		for pid in p["by_os"].get(os_name, []):
			if not ids.has(pid):
				ids.append(pid)
	for pid in extra:
		if not ids.has(pid):
			ids.append(pid)
	return ids

static func protocol_name(pid: String) -> String:
	var p = load_json("res://data/protocols.json")
	if p is Dictionary and p["protocols"].has(pid):
		return p["protocols"][pid]["name"]
	return pid

static func protocol_names_for(os_list: Array, extra: Array = []) -> Array:
	var out: Array = []
	for pid in protocol_ids_for(os_list, extra):
		out.append(protocol_name(pid))
	return out

static func is_private_ipv4(s: String) -> bool:
	var p := s.strip_edges().split(".")
	if p.size() != 4:
		return false
	var n: Array = []
	for x in p:
		if not x.is_valid_int():
			return false
		var v := int(x)
		if v < 0 or v > 255:
			return false
		n.append(v)
	return n[0] == 10 or (n[0] == 172 and n[1] >= 16 and n[1] <= 31) or (n[0] == 192 and n[1] == 168) or (n[0] == 169 and n[1] == 254)

static func load_saved() -> void:
	if _loaded:
		return
	_loaded = true
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f:
		var d = JSON.parse_string(f.get_as_text())
		if d is Array:
			saved = d

static func _write() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(saved))

static func save_device(d: Dictionary) -> void:
	load_saved()
	for i in saved.size():
		if saved[i].get("id", "") == d.get("id", ""):
			saved[i] = d
			_write()
			return
	saved.append(d)
	_write()

static func remove_device(id: String) -> void:
	load_saved()
	saved = saved.filter(func(x): return x.get("id", "") != id)
	_write()
