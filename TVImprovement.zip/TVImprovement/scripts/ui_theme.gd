class_name UI
extends RefCounted
## Единый стиль приложения.

const BG := Color("0b1530")
const SURFACE := Color("1e2430")
const BORDER := Color("2c3b57")
const ACCENT := Color("38b6ff")
const BLUE := Color("1f6feb")
const TEXT := Color("ffffff")
const MUTED := Color("9aa4b5")
const OK := Color("2ecc71")
const ERR := Color("ff5252")

static func box(c: Color, radius: int = 24, border: Color = Color.TRANSPARENT, bw: int = 0, pad: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(radius)
	if bw > 0:
		s.border_color = border
		s.set_border_width_all(bw)
	s.set_content_margin_all(pad)
	return s

static func label(text: String, size: int = 32, color: Color = TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

static func _style_button(b: Button, base: Color, radius: int, border: Color, bw: int) -> void:
	b.add_theme_stylebox_override("normal", box(base, radius, border, bw, 16))
	b.add_theme_stylebox_override("hover", box(base.lightened(0.08), radius, border, bw, 16))
	b.add_theme_stylebox_override("pressed", box(base.darkened(0.2), radius, ACCENT, 3, 16))
	b.add_theme_stylebox_override("focus", box(base, radius, ACCENT, 3, 16))
	b.add_theme_color_override("font_color", TEXT)
	b.add_theme_color_override("font_hover_color", TEXT)
	b.add_theme_color_override("font_pressed_color", TEXT)

static func button(text: String, primary: bool = true, height: int = 130) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, height)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 38)
	_style_button(b, BLUE if primary else SURFACE, 32, BORDER, 0 if primary else 2)
	return b

static func card_button(icon: String, text: String) -> Button:
	var b := Button.new()
	b.text = icon + "\n" + text
	b.custom_minimum_size = Vector2(0, 240)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.add_theme_font_size_override("font_size", 34)
	_style_button(b, SURFACE, 32, BORDER, 2)
	return b

## Карточка: PanelContainer с VBoxContainer внутри (card.get_child(0)).
static func card() -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", box(SURFACE, 28, BORDER, 2, 32))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	p.add_child(v)
	return p

static func logo(size: int = 44) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 14)
	var badge := PanelContainer.new()
	badge.add_theme_stylebox_override("panel", box(BLUE, int(size * 0.35), ACCENT, 3, int(size * 0.3)))
	var tv := Label.new()
	tv.text = "TV"
	tv.add_theme_font_size_override("font_size", size)
	tv.add_theme_color_override("font_color", TEXT)
	badge.add_child(tv)
	h.add_child(badge)
	var title := Label.new()
	title.text = "IMPROVEMENT"
	title.add_theme_font_size_override("font_size", size)
	title.add_theme_color_override("font_color", ACCENT)
	h.add_child(title)
	return h

static func set_primary(b: Button, primary: bool) -> void:
	_style_button(b, BLUE if primary else SURFACE, 32, BORDER, 0 if primary else 2)

static func line_edit(placeholder: String, text: String = "") -> LineEdit:
	var e := LineEdit.new()
	e.placeholder_text = placeholder
	e.text = text
	e.custom_minimum_size = Vector2(0, 110)
	e.add_theme_font_size_override("font_size", 36)
	e.add_theme_stylebox_override("normal", box(SURFACE, 24, BORDER, 2, 20))
	e.add_theme_stylebox_override("focus", box(SURFACE, 24, ACCENT, 3, 20))
	e.add_theme_color_override("font_color", TEXT)
	e.add_theme_color_override("font_placeholder_color", MUTED)
	return e

static func option(items: Array, selected: int = 0) -> OptionButton:
	var o := OptionButton.new()
	for i in items:
		o.add_item(str(i))
	o.select(selected)
	o.custom_minimum_size = Vector2(0, 110)
	o.add_theme_font_size_override("font_size", 34)
	o.get_popup().add_theme_font_size_override("font_size", 34)
	o.get_popup().add_theme_constant_override("v_separation", 24)
	_style_button(o, SURFACE, 24, BORDER, 2)
	return o

static func dialog(parent: Node, title: String, text: String, on_ok: Callable = Callable(), confirm: bool = false) -> void:
	var d: AcceptDialog = ConfirmationDialog.new() if confirm else AcceptDialog.new()
	d.title = title
	d.dialog_text = text
	d.dialog_autowrap = true
	d.min_size = Vector2i(900, 420)
	d.get_label().add_theme_font_size_override("font_size", 32)
	d.ok_button_text = Loc.t("continue") if confirm else Loc.t("ok")
	d.get_ok_button().add_theme_font_size_override("font_size", 34)
	d.get_ok_button().custom_minimum_size = Vector2(0, 100)
	if confirm:
		var c := (d as ConfirmationDialog).get_cancel_button()
		c.text = Loc.t("cancel")
		c.add_theme_font_size_override("font_size", 34)
		c.custom_minimum_size = Vector2(0, 100)
	d.confirmed.connect(func():
		if on_ok.is_valid():
			on_ok.call()
		d.queue_free())
	d.canceled.connect(d.queue_free)
	parent.add_child(d)
	d.popup_centered()
