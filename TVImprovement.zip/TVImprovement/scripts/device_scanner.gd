extends BaseScreen
## Этап 3: настоящий поиск в локальной сети (SSDP + mDNS через Android-плагин).

var devices := {}
var scanning := false
var scanned_once := false
var filter := "all"
var sort_by := "name"
var net_lbl: Label
var status_lbl: Label
var scan_btn: Button
var sort_btn: Button
var list_box: VBoxContainer
var filter_btns := {}
var _rebuild_queued := false
var _pulse: Tween

func _ready() -> void:
	build(Loc.t("find_device"))
	Native.event.connect(_on_event)
	var nc := UI.card()
	net_lbl = UI.label("", 30, UI.MUTED)
	nc.get_child(0).add_child(net_lbl)
	body.add_child(nc)
	scan_btn = UI.button("🔍  " + Loc.t("start_scan"), true, 160)
	scan_btn.pressed.connect(_start_scan)
	body.add_child(scan_btn)
	status_lbl = UI.label("", 30, UI.MUTED)
	body.add_child(status_lbl)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	for f in ["all", "tv", "box", "other"]:
		var b := UI.button(Loc.t("filter_" + f), f == filter, 90)
		b.add_theme_font_size_override("font_size", 26)
		b.pressed.connect(_set_filter.bind(f))
		row.add_child(b)
		filter_btns[f] = b
	body.add_child(row)
	sort_btn = UI.button(Loc.t("sort_name"), false, 90)
	sort_btn.add_theme_font_size_override("font_size", 28)
	sort_btn.pressed.connect(_toggle_sort)
	body.add_child(sort_btn)

	list_box = VBoxContainer.new()
	list_box.add_theme_constant_override("separation", 20)
	body.add_child(list_box)
	var manual := UI.button("✍  " + Loc.t("add_manually"), false, 120)
	manual.pressed.connect(App.go.bind("ip_connection"))
	body.add_child(manual)
	_refresh_net()

func _exit_tree() -> void:
	if Native.event.is_connected(_on_event):
		Native.event.disconnect(_on_event)
	if scanning:
		Native.stop_discovery()

func _refresh_net() -> void:
	if not Native.available:
		net_lbl.text = Loc.t("native_missing")
		net_lbl.add_theme_color_override("font_color", UI.ERR)
		return
	var info := Native.network_info()
	if info.get("connected", false):
		net_lbl.text = "🟢 %s: %s (%s)" % [Loc.t("net_ok"), info.get("ip", "?"), info.get("transport", "")]
		net_lbl.add_theme_color_override("font_color", UI.OK)
		if int(info.get("sdk", 0)) >= 37:
			net_lbl.text += "\n" + Loc.t("lan_hint")
	else:
		net_lbl.text = "🔴 " + Loc.t("net_none")
		net_lbl.add_theme_color_override("font_color", UI.ERR)

func _start_scan() -> void:
	if scanning:
		Native.stop_discovery()
		return
	if not Native.available:
		UI.dialog(self, Loc.t("find_device"), Loc.t("native_missing"))
		return
	_refresh_net()
	if not Native.network_info().get("connected", false):
		UI.dialog(self, Loc.t("find_device"), Loc.t("net_none") + ". " + Loc.t("net_none_hint"))
		return
	if not await PermissionsManager.ensure_local_network():
		if is_inside_tree():
			UI.dialog(self, Loc.t("find_device"), Loc.t("perm_denied"))
		return
	devices.clear()
	scanning = true
	scanned_once = true
	_update_status()
	_queue_rebuild()
	Native.start_discovery(9000)

func _on_event(e: Dictionary) -> void:
	match str(e.get("type", "")):
		"device":
			var ip := str(e.get("ip", ""))
			if ip == "" or not scanning:
				return
			devices[ip] = DeviceClassifier.merge(devices.get(ip, {}), e)
			_update_status()
			_queue_rebuild()
		"discovery_finished":
			scanning = false
			_update_status()
			_queue_rebuild()
		"discovery_error":
			status_lbl.text = str(e.get("message", ""))
			status_lbl.add_theme_color_override("font_color", UI.ERR)

func _update_status() -> void:
	if _pulse:
		_pulse.kill()
	status_lbl.modulate.a = 1.0
	status_lbl.add_theme_color_override("font_color", UI.MUTED)
	if scanning:
		status_lbl.text = Loc.t("scanning") % devices.size()
		scan_btn.text = "⏹  " + Loc.t("stop_scan")
		_pulse = create_tween().set_loops()
		_pulse.tween_property(status_lbl, "modulate:a", 0.4, 0.7)
		_pulse.tween_property(status_lbl, "modulate:a", 1.0, 0.7)
	else:
		status_lbl.text = Loc.t("scan_done") % devices.size() if scanned_once else ""
		scan_btn.text = "🔍  " + Loc.t("rescan" if scanned_once else "start_scan")

func _set_filter(f: String) -> void:
	filter = f
	for k in filter_btns:
		UI.set_primary(filter_btns[k], k == filter)
	_queue_rebuild()

func _toggle_sort() -> void:
	sort_by = "ip" if sort_by == "name" else "name"
	sort_btn.text = Loc.t("sort_" + sort_by)
	_queue_rebuild()

func _queue_rebuild() -> void:
	if _rebuild_queued:
		return
	_rebuild_queued = true
	_rebuild.call_deferred()

func _passes(d: Dictionary) -> bool:
	match filter:
		"tv": return d["type"] == "tv"
		"box": return d["type"] == "box"
		"other": return d["type"] == "unknown" or d["type"] == "media"
	return true

func _ip_key(ip: String) -> int:
	var p := ip.split(".")
	if p.size() != 4:
		return 0
	return (int(p[0]) << 24) | (int(p[1]) << 16) | (int(p[2]) << 8) | int(p[3])

func _rebuild() -> void:
	_rebuild_queued = false
	if not is_inside_tree():
		return
	for c in list_box.get_children():
		c.queue_free()
	var arr: Array = []
	for ip in devices:
		if _passes(devices[ip]):
			arr.append(devices[ip])
	if sort_by == "ip":
		arr.sort_custom(func(a, b): return _ip_key(a["ip"]) < _ip_key(b["ip"]))
	else:
		arr.sort_custom(func(a, b):
			var ra: int = 0 if a["type"] in ["tv", "box"] else 1
			var rb: int = 0 if b["type"] in ["tv", "box"] else 1
			if ra != rb:
				return ra < rb
			return _title(a).to_lower() < _title(b).to_lower())
	if arr.is_empty() and scanned_once and not scanning:
		var c := UI.card()
		c.get_child(0).add_child(UI.label(Loc.t("none_found"), 30, UI.MUTED))
		list_box.add_child(c)
	for d in arr:
		list_box.add_child(_card(d))

func _title(d: Dictionary) -> String:
	for k in ["name", "model"]:
		if str(d[k]) != "":
			return str(d[k])
	return Loc.t("unknown_device")

func _card(d: Dictionary) -> Control:
	var c := UI.card()
	var v: VBoxContainer = c.get_child(0)
	var icon: String = {"tv": "📺", "box": "📦", "media": "📡"}.get(d["type"], "❔")
	v.add_child(UI.label("%s  %s" % [icon, _title(d)], 38))
	var sub: Array = []
	if str(d["brand"]) != "":
		sub.append(str(d["brand"]))
	if str(d["model"]) != "" and str(d["model"]) != _title(d):
		sub.append(str(d["model"]))
	if not sub.is_empty():
		v.add_child(UI.label(" · ".join(PackedStringArray(sub)), 30, UI.MUTED))
	v.add_child(UI.label("IP: " + str(d["ip"]), 30, UI.MUTED))
	var tcol := UI.OK if d["type"] in ["tv", "box"] else (UI.ACCENT if d["type"] == "media" else UI.MUTED)
	v.add_child(UI.label(Loc.t("type_" + str(d["type"])), 28, tcol))
	v.add_child(UI.label("🟢 " + Loc.t("answered"), 26, UI.MUTED))
	if not d["protocols"].is_empty():
		var names: Array = []
		for pid in d["protocols"]:
			names.append(DeviceManager.protocol_name(pid))
		v.add_child(UI.label(Loc.t("protocols_label") + ": " + ", ".join(PackedStringArray(names)), 26, UI.MUTED))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	var b1 := UI.button(Loc.t("details"), false, 100)
	b1.pressed.connect(_details.bind(d))
	var b2 := UI.button(Loc.t("connect"), true, 100)
	b2.pressed.connect(_connect.bind(d))
	row.add_child(b1)
	row.add_child(b2)
	v.add_child(row)
	return c

func _details(d: Dictionary) -> void:
	var lines: Array = ["IP: " + str(d["ip"])]
	for k in ["name", "manufacturer", "model", "device_type", "server"]:
		if str(d[k]) != "":
			lines.append("%s: %s" % [k, d[k]])
	lines.append(Loc.t("sources") + ":")
	for s in d["services"]:
		lines.append("  • " + str(s))
	if not d["txt"].is_empty():
		lines.append("TXT: " + str(d["txt"]))
	UI.dialog(self, _title(d), "\n".join(PackedStringArray(lines)))

func _connect(d: Dictionary) -> void:
	DeviceManager.pending = d.duplicate(true)
	App.go("ip_connection")
