extends Node
## Autoload "Native": мост к Android-плагину TVImprovement. События забираются опросом очереди.

signal event(data: Dictionary)

var plugin: Object = null
var available := false
var _seq := 0

func _ready() -> void:
	if Engine.has_singleton("TVImprovement"):
		plugin = Engine.get_singleton("TVImprovement")
		available = true
		var t := Timer.new()
		t.wait_time = 0.2
		t.timeout.connect(_poll)
		add_child(t)
		t.start()

func _poll() -> void:
	var raw = plugin.call("pollEvents")
	if raw == null or str(raw) == "[]":
		return
	var arr = JSON.parse_string(str(raw))
	if arr is Array:
		for e in arr:
			if e is Dictionary:
				event.emit(e)

func _id() -> String:
	_seq += 1
	return "r%d" % _seq

func network_info() -> Dictionary:
	if not available:
		return {"connected": false, "sdk": 0}
	var d = JSON.parse_string(str(plugin.call("getNetworkInfo")))
	return d if d is Dictionary else {"connected": false, "sdk": 0}

func start_discovery(ms: int) -> void:
	if available:
		plugin.call("startDiscovery", ms)

func stop_discovery() -> void:
	if available:
		plugin.call("stopDiscovery")

func test_tcp(host: String, port: int, timeout_ms: int = 2500) -> String:
	var id := _id()
	if available:
		plugin.call("testTcp", id, host, port, timeout_ms)
	return id

func adb_connect(host: String, port: int) -> void:
	if available:
		plugin.call("adbConnect", host, port)

func adb_shell(cmd: String) -> String:
	var id := _id()
	if available:
		plugin.call("adbShell", id, cmd)
	return id

func adb_disconnect() -> void:
	if available:
		plugin.call("adbDisconnect")

func wait_event(type: String, id: String) -> Dictionary:
	while true:
		var e: Dictionary = await event
		if e.get("type", "") == type and e.get("id", "") == id:
			return e
	return {}
