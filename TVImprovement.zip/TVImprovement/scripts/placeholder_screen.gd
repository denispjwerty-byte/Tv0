extends BaseScreen
## Честная заглушка для функций, которых ещё нет. Не показывает фиктивных данных.

@export var title_key := ""
@export var stage := 0
@export var nav := ""

func _ready() -> void:
	build(Loc.t(title_key), true, true, nav)
	var c := UI.card()
	var v: VBoxContainer = c.get_child(0)
	v.add_child(UI.label(Loc.t("not_ready_title"), 38, UI.ACCENT))
	v.add_child(UI.label(Loc.t("not_ready_text") % stage, 32, UI.MUTED))
	body.add_child(c)
