class_name UnsupportedAdapter
extends DeviceAdapter
## Протокол есть в каталоге, но адаптер ещё не написан. Подключение не имитируется.

var _pid := ""

func _init(pid: String = "") -> void:
	_pid = pid

func protocol_id() -> String:
	return _pid
