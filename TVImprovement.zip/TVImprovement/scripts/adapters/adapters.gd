class_name Adapters
extends RefCounted

static func for_protocol(pid: String) -> DeviceAdapter:
	match pid:
		"adb_tcp":
			return AndroidTvAdapter.new()
		_:
			return UnsupportedAdapter.new(pid)
