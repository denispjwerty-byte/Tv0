class_name DeviceAdapter
extends RefCounted
## Общий интерфейс адаптеров протоколов (Android TV/ADB, Samsung, LG, Apple TV ...).

signal state_changed(state: String, message: String)

func protocol_id() -> String:
	return ""

func is_implemented() -> bool:
	return false

func unsupported_reason() -> String:
	return Loc.t("adapter_later") % DeviceManager.protocol_name(protocol_id())

func confirm_text() -> String:
	return ""

## Реально работающие функции адаптера (ключи: info, apps, install, ads, launcher, remote)
func capabilities() -> Array:
	return []

func connect_device(_host: String, _port: int) -> Dictionary:
	return {"ok": false, "error": unsupported_reason()}

func disconnect_device() -> void:
	pass

func fetch_info() -> Dictionary:
	return {}
