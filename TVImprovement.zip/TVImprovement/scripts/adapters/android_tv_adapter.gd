class_name AndroidTvAdapter
extends DeviceAdapter
## ADB по сети. Авторизация: пользователь подтверждает RSA-ключ на экране устройства.

func protocol_id() -> String:
	return "adb_tcp"

func is_implemented() -> bool:
	return Native.available

func unsupported_reason() -> String:
	return Loc.t("native_missing")

func confirm_text() -> String:
	return Loc.t("adb_confirm")

func capabilities() -> Array:
	return ["info"]

func connect_device(host: String, port: int) -> Dictionary:
	Native.adb_connect(host, port)
	while true:
		var e: Dictionary = await Native.event
		if e.get("type", "") != "adb_state":
			continue
		var s := str(e.get("state", ""))
		state_changed.emit(s, str(e.get("message", "")))
		if s == "connected":
			return {"ok": true, "banner": str(e.get("banner", ""))}
		if s == "error" or s == "disconnected":
			return {"ok": false, "error": str(e.get("message", s))}
	return {"ok": false, "error": "unknown"}

func disconnect_device() -> void:
	Native.adb_disconnect()

## Запрашиваем только пять нужных свойств (ничего лишнего).
func fetch_info() -> Dictionary:
	var keys := {
		"manufacturer": "ro.product.manufacturer", "model": "ro.product.model",
		"android": "ro.build.version.release", "sdk": "ro.build.version.sdk",
		"characteristics": "ro.build.characteristics",
	}
	var out := {}
	for k in keys:
		var id := Native.adb_shell("getprop " + keys[k])
		var e: Dictionary = await Native.wait_event("adb_shell", id)
		if e.get("ok", false):
			out[k] = str(e.get("output", "")).strip_edges()
	out["os"] = "Android TV" if str(out.get("characteristics", "")).contains("tv") else "Android"
	return out
