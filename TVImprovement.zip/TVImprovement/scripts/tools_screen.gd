extends BaseScreen

const TOOLS := [
	["ip_connection", "ip_connect", "🌐"],
	["app_installer", "install_apps", "📦"],
	["ad_cleaner", "ad_cleaner", "🧹"],
	["launcher_store", "launcher", "🚀"],
	["tv_remote", "remote", "🎮"],
	["instructions", "instructions", "📖"],
]

func _ready() -> void:
	build(Loc.t("nav_tools"), false, true, "tools")
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 24)
	grid.add_theme_constant_override("v_separation", 24)
	body.add_child(grid)
	for it in TOOLS:
		var b := UI.card_button(it[2], Loc.t(it[1]))
		b.pressed.connect(App.go.bind(it[0]))
		grid.add_child(b)
