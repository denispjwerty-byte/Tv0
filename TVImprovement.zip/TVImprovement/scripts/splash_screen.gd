extends BaseScreen

func _ready() -> void:
	build("", false, false)
	var c := CenterContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(c)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 40)
	c.add_child(v)
	v.add_child(UI.logo(72))
	var sub := UI.label(Loc.t("tagline"), 34, UI.MUTED)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(sub)
	await get_tree().create_timer(1.4).timeout
	App.go("main", false)
