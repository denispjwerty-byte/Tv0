extends BaseScreen
## Этап 6: панель подключённого устройства (показывает только реально полученные данные).

var state_lbl: Label

const FEATURES := [["info", "feature_info", 6], ["apps", "feature_apps", 7], ["install", "feature_install", 7],
	["ads", "feature_ads", 8], ["launcher", "feature_launcher", 9], ["remote", "feature_remote", 10]]

func _ready() -> void:
	build(Loc.t("device_info"))
	var s := DeviceManager.session
	if s.is_empty():
		var c := UI.card()
		c.get_child(0).add_child(UI.label(Loc.t("no_session"), 32, UI.MUTED))
		body.add_child(c)
		var b := UI.button("🔍  " + Loc.t("find_device"), true, 140)
		b.pressed.connect(App.go.bind("device_scanner"))
		body.add_child(b)
		return
	Native.event.connect(_on_event)
	var c := UI.card()
	var v: VBoxContainer = c.get_child(0)
	v.add_child(UI.label(str(s["name"]), 42))
	state_lbl = UI.label("🟢 " + Loc.t("connected"), 30, UI.OK)
	v.add_child(state_lbl)
	_row(v, Loc.t("brand"), s.get("brand", ""))
	_row(v, Loc.t("model"), s.get("model", ""))
	_row(v, Loc.t("ip"), "%s:%s" % [s["ip"], s["port"]])
	_row(v, Loc.t("protocol"), DeviceManager.protocol_name(str(s["protocol"])))
	_row(v, "OS", s.get("os", ""))
	_row(v, Loc.t("os_version"), "%s (SDK %s)" % [s.get("os_version", ""), s.get("sdk", "")])
	body.add_child(c)

	body.add_child(UI.label(Loc.t("features"), 40, UI.ACCENT))
	var caps: Array = DeviceManager.adapter.capabilities() if DeviceManager.adapter else []
	var fc := UI.card()
	for f in FEATURES:
		var ok: bool = caps.has(f[0])
		var t := ("✅ " + Loc.t(f[1])) if ok else ("⏳ %s — %s" % [Loc.t(f[1]), Loc.t("feature_soon") % f[2]])
		fc.get_child(0).add_child(UI.label(t, 30, UI.TEXT if ok else UI.MUTED))
	body.add_child(fc)

	var r := UI.button(Loc.t("refresh_info"), false, 120)
	r.pressed.connect(_refresh)
	body.add_child(r)
	var sv := UI.button(Loc.t("save_device"), false, 120)
	sv.pressed.connect(_save)
	body.add_child(sv)
	var d := UI.button(Loc.t("disconnect"), true, 130)
	d.pressed.connect(_disconnect)
	body.add_child(d)

func _exit_tree() -> void:
	if Native.event.is_connected(_on_event):
		Native.event.disconnect(_on_event)

func _row(v: VBoxContainer, k: String, val) -> void:
	if str(val).strip_edges() != "":
		v.add_child(UI.label("%s: %s" % [k, val], 28, UI.MUTED))

func _on_event(e: Dictionary) -> void:
	if e.get("type", "") == "adb_state" and e.get("state", "") in ["disconnected", "error"]:
		DeviceManager.session["connected"] = false
		if state_lbl:
			state_lbl.text = "🔴 " + Loc.t("connection_lost")
			state_lbl.add_theme_color_override("font_color", UI.ERR)

func _refresh() -> void:
	if DeviceManager.adapter == null or not DeviceManager.session.get("connected", false):
		return
	var info: Dictionary = await DeviceManager.adapter.fetch_info()
	if info.is_empty():
		return
	DeviceManager.session["os"] = str(info.get("os", DeviceManager.session["os"]))
	DeviceManager.session["os_version"] = str(info.get("android", ""))
	DeviceManager.session["sdk"] = str(info.get("sdk", ""))
	if is_inside_tree():
		get_tree().reload_current_scene()

func _save() -> void:
	var s := DeviceManager.session
	DeviceManager.save_device({
		"id": "%s:%s:%s" % [s["ip"], s["port"], s["protocol"]], "name": s["name"], "brand_id": s.get("brand_id", ""),
		"model": s.get("model", ""), "type": s.get("type", "unknown"), "ip": s["ip"], "port": int(s["port"]), "protocol": s["protocol"],
	})
	UI.dialog(self, Loc.t("save_device"), Loc.t("saved_ok"))

func _disconnect() -> void:
	if DeviceManager.adapter:
		DeviceManager.adapter.disconnect_device()
	DeviceManager.session = {}
	DeviceManager.adapter = null
	App.go_root("main")
