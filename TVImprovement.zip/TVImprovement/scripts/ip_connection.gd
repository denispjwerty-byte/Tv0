extends BaseScreen
## Этапы 4 и 6: ручное подключение по IP, проверка TCP, подключение через адаптер, сохранение.

const TYPE_KEYS := ["unknown", "tv", "box"]
var ip_e: LineEdit
var port_e: LineEdit
var type_o: OptionButton
var brand_o: OptionButton
var model_e: LineEdit
var proto_o: OptionButton
var status: Label
var proto_ids: Array = []
var protos := {}
var brand_ids: Array = [""]
var _last_default_port := ""
var _busy := false

func _ready() -> void:
	build(Loc.t("ip_connect"))
	protos = DeviceManager.load_json("res://data/protocols.json")["protocols"]
	var pnames: Array = []
	for pid in protos:
		proto_ids.append(pid)
		var nm: String = protos[pid]["name"]
		if not protos[pid].get("implemented", false):
			nm += "  (" + Loc.t("soon") + ")"
		pnames.append(nm)
	var bnames: Array = [Loc.t("not_selected")]
	for it in DeviceManager.catalog("res://data/tv_brands.json") + DeviceManager.catalog("res://data/tv_boxes.json"):
		brand_ids.append(it["id"])
		bnames.append(it["name"])

	_cap(Loc.t("ip"))
	ip_e = UI.line_edit("192.168.1.50")
	ip_e.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_URL
	body.add_child(ip_e)
	_cap(Loc.t("protocol"))
	proto_o = UI.option(pnames, 0)
	proto_o.item_selected.connect(func(_i): _apply_default_port())
	body.add_child(proto_o)
	_cap(Loc.t("port"))
	port_e = UI.line_edit("5555")
	port_e.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	body.add_child(port_e)
	_cap(Loc.t("device_type"))
	type_o = UI.option([Loc.t("type_unknown"), Loc.t("type_tv"), Loc.t("type_box")], 0)
	body.add_child(type_o)
	_cap(Loc.t("brand"))
	brand_o = UI.option(bnames, 0)
	body.add_child(brand_o)
	_cap(Loc.t("model"))
	model_e = UI.line_edit("")
	body.add_child(model_e)

	status = UI.label("", 30, UI.MUTED)
	body.add_child(status)
	var b1 := UI.button(Loc.t("check_conn"), false, 120)
	b1.pressed.connect(_on_test)
	var b2 := UI.button(Loc.t("connect_btn"), true, 140)
	b2.pressed.connect(_on_connect)
	var b3 := UI.button(Loc.t("save_device"), false, 120)
	b3.pressed.connect(_on_save)
	body.add_child(b1)
	body.add_child(b2)
	body.add_child(b3)
	_prefill()
	_apply_default_port()

func _cap(t: String) -> void:
	body.add_child(UI.label(t, 28, UI.MUTED))

func _prefill() -> void:
	var p := DeviceManager.pending
	if p.is_empty():
		return
	DeviceManager.pending = {}
	ip_e.text = str(p.get("ip", ""))
	model_e.text = str(p.get("model", ""))
	var bi: int = brand_ids.find(str(p.get("brand_id", "")))
	if bi > 0:
		brand_o.select(bi)
	var ti: int = TYPE_KEYS.find(str(p.get("type", "")))
	if ti > 0:
		type_o.select(ti)
	var plist: Array = p.get("protocols", [])
	if plist.is_empty() and p.has("protocol"):
		plist = [p["protocol"]]
	var chosen := -1
	for pid in plist:
		var i: int = proto_ids.find(pid)
		if i >= 0 and (chosen < 0 or protos[pid].get("implemented", false)):
			chosen = i
			if protos[pid].get("implemented", false):
				break
	if chosen >= 0:
		proto_o.select(chosen)
	if int(p.get("port", 0)) > 0:
		port_e.text = str(int(p["port"]))
		_last_default_port = ""

func _apply_default_port() -> void:
	var ports: Array = protos[proto_ids[proto_o.selected]].get("ports", [])
	if ports.is_empty():
		return
	if port_e.text == "" or port_e.text == _last_default_port:
		port_e.text = str(int(ports[0]))
		_last_default_port = port_e.text

func _set_status(t: String, col: Color = UI.MUTED) -> void:
	if is_inside_tree():
		status.text = t
		status.add_theme_color_override("font_color", col)

func _validate() -> Dictionary:
	var ip := ip_e.text.strip_edges()
	if not DeviceManager.is_private_ipv4(ip):
		_set_status(Loc.t("bad_ip"), UI.ERR)
		return {"ok": false}
	var port_s := port_e.text.strip_edges()
	if not port_s.is_valid_int() or int(port_s) < 1 or int(port_s) > 65535:
		_set_status(Loc.t("bad_port"), UI.ERR)
		return {"ok": false}
	return {"ok": true, "ip": ip, "port": int(port_s)}

func _on_test() -> void:
	if _busy:
		return
	var v := _validate()
	if not v.ok:
		return
	if not Native.available:
		_set_status(Loc.t("native_missing"), UI.ERR)
		return
	_busy = true
	_set_status(Loc.t("checking"))
	var id := Native.test_tcp(v.ip, v.port)
	var e := await Native.wait_event("tcp_result", id)
	_busy = false
	if e.get("ok", false):
		_set_status(Loc.t("tcp_ok") % [v.port, v.ip], UI.OK)
	else:
		_set_status(Loc.t("tcp_fail") % [v.ip, v.port, str(e.get("error", ""))], UI.ERR)

func _on_connect() -> void:
	if _busy:
		return
	var v := _validate()
	if not v.ok:
		return
	var adapter := Adapters.for_protocol(proto_ids[proto_o.selected])
	if not adapter.is_implemented():
		_set_status(adapter.unsupported_reason(), UI.ERR)
		return
	UI.dialog(self, Loc.t("confirm_title"), adapter.confirm_text(), _do_connect.bind(adapter, v.ip, v.port), true)

func _do_connect(adapter: DeviceAdapter, ip: String, port: int) -> void:
	_busy = true
	adapter.state_changed.connect(func(s: String, _m: String): _set_status(Loc.t("state_" + s)))
	var res: Dictionary = await adapter.connect_device(ip, port)
	if not res.get("ok", false):
		_busy = false
		_set_status(Loc.t("conn_failed") % str(res.get("error", "")) + "\n\n" + Loc.t("adb_help"), UI.ERR)
		return
	var info: Dictionary = await adapter.fetch_info()
	_busy = false
	var nm := ("%s %s" % [info.get("manufacturer", ""), info.get("model", "")]).strip_edges()
	DeviceManager.adapter = adapter
	DeviceManager.session = {
		"name": nm if nm != "" else ip, "brand": brand_o.get_item_text(brand_o.selected) if brand_o.selected > 0 else str(info.get("manufacturer", "")),
		"model": str(info.get("model", model_e.text)), "ip": ip, "port": port, "protocol": adapter.protocol_id(),
		"os": str(info.get("os", "")), "os_version": str(info.get("android", "")), "sdk": str(info.get("sdk", "")),
		"type": TYPE_KEYS[type_o.selected], "brand_id": brand_ids[brand_o.selected], "connected": true,
	}
	if is_inside_tree():
		App.go("device_details")

func _on_save() -> void:
	var v := _validate()
	if not v.ok:
		return
	var brand := brand_o.get_item_text(brand_o.selected) if brand_o.selected > 0 else ""
	DeviceManager.save_device({
		"id": "%s:%d:%s" % [v.ip, v.port, proto_ids[proto_o.selected]],
		"name": model_e.text if model_e.text != "" else (brand if brand != "" else v.ip),
		"brand_id": brand_ids[brand_o.selected], "model": model_e.text, "type": TYPE_KEYS[type_o.selected],
		"ip": v.ip, "port": v.port, "protocol": proto_ids[proto_o.selected],
	})
	_set_status(Loc.t("saved_ok"), UI.OK)
