class_name DeviceClassifier
extends RefCounted
## Объединяет ответы SSDP/mDNS по IP и осторожно определяет тип. Нет сильного признака -> "unknown".
## type: tv | box | media (подтверждённое медиа-устройство, ТВ/приставку выбирает пользователь) | unknown

const ALIASES := {
	"lge": "lg", "webos": "lg", "bravia": "sony", "mibox": "mi_box", "mi box": "mi_box",
	"chromecast": "chromecast", "firetv": "fire_tv", "fire tv": "fire_tv",
	"appletv": "apple_tv", "apple tv": "apple_tv", "shield": "shield",
}
static var _cat: Array = []

static func _catalog() -> Array:
	if _cat.is_empty():
		for it in DeviceManager.catalog("res://data/tv_brands.json"):
			var y: Dictionary = it.duplicate()
			y["kind"] = "tv"
			_cat.append(y)
		for it in DeviceManager.catalog("res://data/tv_boxes.json"):
			var y: Dictionary = it.duplicate()
			y["kind"] = "box"
			_cat.append(y)
	return _cat

static func merge(d: Dictionary, e: Dictionary) -> Dictionary:
	if d.is_empty():
		d = {"ip": str(e.get("ip", "")), "name": "", "manufacturer": "", "model": "", "server": "",
			"device_type": "", "services": [], "txt": {}, "locations": []}
	for k in ["name", "manufacturer", "model", "server", "device_type"]:
		var v := str(e.get(k, "")).strip_edges()
		if v != "" and str(d[k]) == "":
			d[k] = v
	var tag := ""
	if e.get("source", "") == "ssdp":
		if str(e.get("st", "")) != "":
			tag = "ssdp:" + str(e["st"])
		var loc := str(e.get("location", ""))
		if loc != "" and not d["locations"].has(loc):
			d["locations"].append(loc)
	elif e.get("source", "") == "mdns":
		tag = "mdns:" + str(e.get("service", "")) + ":" + str(e.get("port", ""))
	if tag != "" and not d["services"].has(tag):
		d["services"].append(tag)
	var txt = e.get("txt")
	if txt is Dictionary:
		for k in txt:
			d["txt"][k] = txt[k]
	if d["txt"].has("fn"):
		d["name"] = d["txt"]["fn"]
	if str(d["model"]) == "":
		d["model"] = str(d["txt"].get("md", d["txt"].get("model", "")))
	_analyze(d)
	return d

static func _match_brand(text: String) -> String:
	for k in ALIASES:
		if text.contains(k):
			return ALIASES[k]
	for it in _catalog():
		var re := RegEx.create_from_string("\\b" + String(it["name"]).to_lower() + "\\b")
		if re.search(text) != null:
			return it["id"]
	return ""

static func _analyze(d: Dictionary) -> void:
	var text := " ".join([str(d["name"]), str(d["manufacturer"]), str(d["model"]), str(d["server"]),
		str(d["device_type"]), str(d["txt"])]).to_lower()
	var svc := " ".join(PackedStringArray(d["services"])).to_lower()
	var brand_id := _match_brand(text)
	var type := "unknown"
	var os := ""
	var conf := "none"
	var extra: Array = []

	if svc.contains("_androidtvremote2._tcp"):
		type = "media"; os = "Android TV"; conf = "high"
	if svc.contains("_samsungmsf._tcp") or str(d["name"]).begins_with("[TV]"):
		type = "tv"; os = "Tizen"; brand_id = "samsung"; conf = "high" if svc.contains("_samsungmsf") else "medium"
	if text.contains("webos") or text.contains("lge"):
		type = "tv"; os = "webOS"; brand_id = "lg"; conf = "medium"
	if svc.contains("roku:ecp"):
		type = "media"; os = "Roku OS"; conf = "high"
	if text.contains("bravia"):
		type = "tv"; brand_id = "sony"; conf = "high"
		if os == "":
			os = "Android TV"
		extra.append("sony_bravia")
	if svc.contains("_googlecast._tcp"):
		extra.append("cast_v2")
		if type == "unknown" and RegEx.create_from_string("chromecast|\\btv\\b|shield|mi box").search(text) != null:
			type = "media"; os = "Google Cast"; conf = "medium"
	if svc.contains("_airplay._tcp") and text.contains("appletv"):
		type = "box"; os = "tvOS"; brand_id = "apple_tv"; conf = "high"

	var brand_name := ""
	for it in _catalog():
		if it["id"] == brand_id:
			brand_name = it["name"]
			if type == "media":
				type = it["kind"]
	d["brand_id"] = brand_id
	d["brand"] = brand_name if brand_name != "" else str(d["manufacturer"])
	d["type"] = type
	d["os"] = os
	d["confidence"] = conf
	d["protocols"] = DeviceManager.protocol_ids_for([os] if os != "" else [], extra)
